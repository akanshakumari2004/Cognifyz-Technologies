import java.util.Scanner;

    public class NumberPyramid {
        public static void main(String[] args) {
            Scanner sc = new Scanner(System.in);
            System.out.print("Enter pyramid size: ");
            int size = sc.nextInt();

            for (int i = 1; i <= size; i++) {
                // (1) spaces to center the pyramid
                for (int j = i; j < size; j++) {
                    System.out.print(" ");
                }
                // (2) numbers from 1 to i
                for (int j = 1; j <= i; j++) {
                    System.out.print(j + " ");
                }
                System.out.println();
            }

            sc.close();
        }
    }

