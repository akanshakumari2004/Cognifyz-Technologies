import java.util.Scanner;

public class TemperatureConverter {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Welcome to Temperature Converter!");
        System.out.print("Enter the temperature value: ");
        double inputTemp = sc.nextDouble();

        System.out.println("Choose conversion direction:");
        System.out.println("1: Celsius → Fahrenheit");
        System.out.println("2: Fahrenheit → Celsius");
        System.out.print("Enter 1 or 2: ");
        int choice = sc.nextInt();

        double outputTemp;
        switch (choice) {
            case 1:
                outputTemp = celsiusToFahrenheit(inputTemp);
                System.out.printf("%.2f °C = %.2f °F%n", inputTemp, outputTemp);
                break;
            case 2:
                outputTemp = fahrenheitToCelsius(inputTemp);
                System.out.printf("%.2f °F = %.2f °C%n", inputTemp, outputTemp);
                break;
            default:
                System.out.println("Invalid choice. Please run the program again and enter 1 or 2.");
                sc.close();
                return;
        }

        sc.close();
    }

    // Conversion formulas
    public static double celsiusToFahrenheit(double c) {
        return (c * 9 / 5) + 32;
    }

    public static double fahrenheitToCelsius(double f) {
        return (f - 32) * 5 / 9;
    }
}
