﻿using System;
using System.Collections.Generic;

class Task
{
    public string Title { get; set; }
    public string Description { get; set; }

    public void Display()
    {
        Console.WriteLine($"Title: {Title}, Description: {Description}");
    }
}

class Program
{
    static List<Task> tasks = new List<Task>();

    static void Main()
    {
        while (true)
        {
            Console.WriteLine("\n--- Task Manager ---");
            Console.WriteLine("1. Create Task");
            Console.WriteLine("2. Read Tasks");
            Console.WriteLine("3. Update Task");
            Console.WriteLine("4. Delete Task");
            Console.WriteLine("5. Exit");
            Console.Write("Choose an option: ");
            string input = Console.ReadLine();

            switch (input)
            {
                case "1":
                    CreateTask();
                    break;
                case "2":
                    ReadTasks();
                    break;
                case "3":
                    UpdateTask();
                    break;
                case "4":
                    DeleteTask();
                    break;
                case "5":
                    return;
                default:
                    Console.WriteLine("Invalid option. Try again.");
                    break;
            }
        }
    }

    static void CreateTask()
    {
        Console.Write("Enter task title: ");
        string title = Console.ReadLine();
        Console.Write("Enter task description: ");
        string description = Console.ReadLine();

        Task newTask = new Task { Title = title, Description = description };
        tasks.Add(newTask);
        Console.WriteLine("Task created successfully!");
    }

    static void ReadTasks()
    {
        if (tasks.Count == 0)
        {
            Console.WriteLine("No tasks found.");
            return;
        }

        for (int i = 0; i < tasks.Count; i++)
        {
            Console.Write($"{i + 1}. ");
            tasks[i].Display();
        }
    }

    static void UpdateTask()
    {
        ReadTasks();
        Console.Write("Enter the task number to update: ");
        if (int.TryParse(Console.ReadLine(), out int index) && index >= 1 && index <= tasks.Count)
        {
            Console.Write("Enter new title: ");
            tasks[index - 1].Title = Console.ReadLine();
            Console.Write("Enter new description: ");
            tasks[index - 1].Description = Console.ReadLine();
            Console.WriteLine("Task updated successfully!");
        }
        else
        {
            Console.WriteLine("Invalid task number.");
        }
    }

    static void DeleteTask()
    {
        ReadTasks();
        Console.Write("Enter the task number to delete: ");
        if (int.TryParse(Console.ReadLine(), out int index) && index >= 1 && index <= tasks.Count)
        {
            tasks.RemoveAt(index - 1);
            Console.WriteLine("Task deleted successfully!");
        }
        else
        {
            Console.WriteLine("Invalid task number.");
        }
    }
}
